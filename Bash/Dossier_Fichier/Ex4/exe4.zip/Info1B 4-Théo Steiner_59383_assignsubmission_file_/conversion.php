<?php 
// init variables
	$valeurDecimale = 9999;
	$base = 16;
	$resultat = "";
	
	// tant que la valeur n'est pas nulle
	while ($valeurDecimale)
	{
		$reste = $valeurDecimale % $base;
		// remplacement du reste par un caractère hexa
		switch($reste)
		{
			case 10 :
				$reste = "A";
				break;
			case 11 :
				$reste = "B";
				break;
			case 12 :
				$reste = "C";
				break;
			case 13 :
				$reste = "D";
				break;
			case 14 :
				$reste = "E";
				break;
			case 15 :
				$reste = "F";
				break;
		}
		// concaténation du reste avec le résultat
		$resultat = $reste . $resultat;
		// divison par la base avec arrondi à l'entier
		$valeurDecimale = intval($valeurDecimale / $base);
	}
	
	echo "Le résultat de la conversion en hexa est : $resultat";

?> 


